// custom script

jQuery().ready(function(){

  jQuery('.views-field-field-imagenes li a').append('<div class="wrap-span"> <span class="glyphicon glyphicon-zoom-in"></span></div>')

  




// menu icons

// remueve los textos no necesarios
jQuery(".m-custom-item.fa.fa-envelope").text("");
jQuery(".m-custom-item.fa.fa-facebook-square").text("");
jQuery(".m-custom-item.fa.fa-twitter-square").text("");

});


;
